<?php
// Verify the request is coming from Razorpay using the secret key.
$razorpay_secret_key = 'B6S9cO8i3IOANP3259Vc8BlE';

$webhook_secret = '2drRvimF6TX@HDz'; // You can set this when configuring the webhook in Razorpay.

$request_signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'];
$request_body = file_get_contents('php://input');

$expected_signature = hash_hmac('sha256', $request_body, $webhook_secret);

if ($request_signature === $expected_signature) {
    // Request is verified.
    $data = json_decode($request_body, true);
    
    // Access and process the payment information here.
    $payment_id = $data['payload']['payment']['entity']['id'];
    $amount = $data['payload']['payment']['entity']['amount'];
    $status = $data['payload']['payment']['entity']['status'];
    // ... and so on
    
    // Your processing logic here.
} else {
    // Request is not verified, possibly a malicious request.
    http_response_code(403); // Forbidden
    die("Invalid webhook request.");
}
?>
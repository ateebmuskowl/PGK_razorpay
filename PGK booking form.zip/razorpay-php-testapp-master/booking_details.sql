-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2023 at 11:32 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razorpay`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking_details`
--

CREATE TABLE `booking_details` (
  `id` int(255) NOT NULL,
  `options` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `Indian_foreign` varchar(20) NOT NULL,
  `Infant_ticket` int(20) NOT NULL,
  `kids_ticket` int(20) NOT NULL,
  `above12_ticket` int(20) NOT NULL,
  `water_infant_ticket` int(20) NOT NULL,
  `water_kids_ticket` int(20) NOT NULL,
  `water_above12_ticket` int(20) NOT NULL,
  `total_price` varchar(10000) NOT NULL,
  `waterticket` varchar(20) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking_details`
--

INSERT INTO `booking_details` (`id`, `options`, `date`, `Indian_foreign`, `Infant_ticket`, `kids_ticket`, `above12_ticket`, `water_infant_ticket`, `water_kids_ticket`, `water_above12_ticket`, `total_price`, `waterticket`, `order_id`, `payment_status`, `payment_id`, `name`, `email`, `number`) VALUES
(22, 'Pratap Gourav Kendra Ticket', '2023-09-13', 'Indian', 0, 6, 0, 0, 0, 0, '660', 'NO', 'order_MYWPg10PLBSMjI', 'successful', 'pay_MYWPyvdotmWgI2', 'aasdfghj', 'sd@gmail.com', '1234567890'),
(23, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 3, 0, 0, 0, 0, '330', 'NO', 'order_MYvvrNNmFpYYBB', 'successful', 'pay_MYvwMRkwVLHHrO', 'Ateeb Haque', 'ateebhaque1912@gmail.com', '9024196730'),
(24, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 0, 6, 0, 6, 0, '1260', 'Yes', 'order_Mdi6eiyTSOnH4A', 'successful', 'pay_Mdi6tDQe4EAAmt', 'ateeb', 'ateebhaque1912@gmail.com', '8279291582'),
(25, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 1, 6, 0, 6, 0, '1070', 'NO', 'order_MdktQbXrPmEQXs', 'successful', 'pay_MdktaTwaJC4TEH', 'ateeb', 'ateebhaque1912@gmail.com', '8279291582'),
(27, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 2, 1, 0, 1, 1, '530', 'Yes', 'order_MdlcPgvnGczTgE', 'successful', 'pay_Mdlcetpx9xFruN', 'ateeb', 'ateeb.muskowl@gmail.com', '1234567890'),
(28, 'Pratap Gourav Kendra Ticket', '2023-09-18', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_Mdletw7I8wauD9', 'successful', 'pay_Mdlfb2fLp0ZRYy', 'ateeb', 'ateeb.muskowl@gmail.com', '1234567890'),
(29, 'Pratap Gourav Kendra Ticket', '2023-09-18', 'Indian', 0, 1, 0, 0, 0, 0, '110', 'NO', 'order_MdlmRbJXSdqWKt', 'successful', 'pay_MdlmcvvDbzSib4', 'ateeb', 'ateeb.muskowl@gmail.com', '1234567890'),
(30, 'Water laser show', '2023-12-18', 'Indian', 0, 4, 0, 0, 0, 0, '200', 'NO', 'order_Mdloe5mIixFuM2', 'successful', 'pay_MdlpHLF5pfsYJa', 'xyz', 'ateeb.muskowl@gmail.com', '0987654321'),
(36, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 7, 0, 0, 0, 0, '770', 'NO', 'order_Me4JkNVAtkOWHN', 'Successful', 'pay_Me4Jsi1C9JVylO', 'Ateeb ', 'hello@gmail.com', '9024196730'),
(37, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Foreign', 1, 2, 3, 1, 4, 5, '2600', 'Yes', 'order_Me4iNsMEZn3yl8', 'Successful', 'pay_Me4iY6SGLewIo9', 'know', 'hello@gmail.com', '4532178965'),
(38, 'Pratap Gourav Kendra Ticket', '2023-09-19', 'Indian', 0, 2, 3, 0, 0, 9, '1600', 'Yes', 'order_Me4mtVdYhsK34i', 'Successful', 'pay_Me4n5ZASVfcqkG', 'known', 'known@gmail.com', '8765678908'),
(39, 'Pratap Gourav Kendra Ticket', '2023-09-30', 'Indian', 0, 7, 0, 0, 0, 0, '770', 'Yes', 'order_Me4sTMibncWMr9', 'Successful', '', 'xyz', 'hello@gmail.com', '9876543218'),
(40, 'Water laser show', '2023-09-22', 'Indian', 0, 1, 0, 0, 0, 0, '50', 'NO', 'order_Me4wmtog18uFnd', 'Successful', 'pay_Me4wv9oyA1efIr', 'xyz', 'ateeb.muskowl@gmail.com', '9024196730'),
(41, 'Water laser show', '2023-09-23', 'Foreign', 0, 2, 2, 0, 0, 0, '300', 'NO', 'order_Me5Bfekin97ISI', 'Successful', 'pay_Me5Bpje956uzVo', 'xyz', 'ateebhaque1912@gmil.com', '9876567890'),
(42, 'Pratap Gourav Kendra Ticket', '2023-09-23', 'Foreign', 0, 2, 2, 0, 6, 0, '1740', 'Yes', 'order_Me5CrGYKqETeTH', 'Successful', 'pay_Me5D0Db1QYtFTa', 'xyz', 'ateebhaque1912@gmil.com', '9876567890'),
(43, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 0, 2, 4, 0, 5, 5, '1610', 'Yes', 'order_Me5HV9v23Ef1le', 'Successful', 'pay_Me5HhUR0Q5qrOe', 'Ateeb ', 'hello@gmail.com', '9876789098'),
(44, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 3, 0, 0, 0, 0, '330', 'NO', 'order_Me9bg0v6vT7IRD', 'Successful', 'pay_Me9dKpkfnwYVh3', 'Ateeb Haque', 'ateeb.muskowl@gmail.com', '8279291582'),
(45, 'Pratap Gourav Kendra Ticket', '2023-09-30', 'Foreign', 0, 1, 0, 0, 0, 0, '260', 'NO', 'order_MeqluHJnPESYBF', 'Successful', 'pay_MeqmFzXtEiErMk', 'hi', 'hi@gmail.com', '9878998765'),
(46, 'Pratap Gourav Kendra Ticket', '2023-09-30', 'Indian', 6, 3, 2, 1, 4, 5, '1350', 'Yes', 'order_MerbqLQzyFdJDv', 'Successful', 'pay_Merbycxm1WRRre', 'hi', 'hi@gmail.com', '9878998765'),
(49, 'Water laser show', '2023-09-22', 'Indian', 0, 5, 0, 0, 0, 0, '250', 'NO', 'order_MerxMEAX3dzgl8', 'Successful', 'pay_MerxV4R7P7sgS6', 'hi', 'hi@gmail.com', '8789098789'),
(50, 'Pratap Gourav Kendra Ticket', '2023-09-21', 'Indian', 0, 1, 0, 0, 6, 0, '410', 'Yes', 'order_Mest8iySNrEDOf', 'Successful', 'pay_MestJW2S3QJxfl', 'hi', 'hi@gmail.com', '7656789098'),
(51, 'Pratap Gourav Kendra Ticket', '2023-09-23', 'Indian', 4, 4, 4, 5, 5, 5, '1830', 'Yes', 'order_MeszHUTcQJUVsS', 'Successful', 'pay_MeszSe3noXKNrK', 'hi', 'hi@gmail.com', '7656787656'),
(52, 'Water laser show', '2023-09-30', 'Foreign', 9, 9, 9, 6, 6, 6, '1350', 'Yes', 'order_Met0sqIgPJnWPV', 'Successful', 'pay_Met12UQUxmKfjm', 'hi', 'hi@gmail.com', '2345654345'),
(53, 'Water laser show', '2023-09-23', 'Indian', 5, 5, 5, 2, 2, 2, '750', 'Yes', 'order_Met6RlLsviFt2z', 'Successful', 'pay_Met6akWnybhyYw', 'hi', 'hi@gmail.com', '3234567876'),
(54, 'Pratap Gourav Kendra Ticket', '2023-09-28', 'Indian', 1, 1, 1, 5, 5, 5, '150', 'NO', 'order_MetBeYKRY2jfOl', 'Successful', 'pay_MetCJrIib4I5p0', 'hi', 'hi@gmail.com', '1234567890'),
(55, 'Water laser show', '2023-09-22', 'Indian', 1, 1, 1, 0, 0, 0, '150', 'NO', 'order_MetHp9g3JAO54r', 'Successful', 'pay_MetIPXFOprTND1', 'hello', 'hello@gmail.com', '5656565656'),
(56, 'Water laser show', '2023-09-22', 'Indian', 0, 0, 0, 0, 0, 0, '500', 'Yes', 'order_MetVoCCXaBfxyn', 'Successful', 'pay_MetW0oIVfi1yWy', 'hello', 'hello@gmail.com', '1234567890'),
(57, 'Water laser show', '2023-09-22', 'Foreign', 0, 0, 0, 3, 3, 3, '450', 'Yes', 'order_MetgnAiOfy24UX', 'Successful', 'pay_MethCGXLQNTmFx', 'hi', 'hi@gmail.com', '3245676543'),
(58, 'Water laser show', '2023-09-22', 'Foreign', 0, 0, 0, 0, 0, 0, '1200', 'Yes', 'order_MettdcB530rRcH', '', '', 'hi', 'hi@gmail.com', '5676545676'),
(59, 'Water laser show', '2023-09-21', 'Foreign', 0, 0, 0, 7, 7, 7, '1050', 'Yes', 'order_MetwAzFqKndOQ3', 'Successful', 'pay_MetwdKAA3aODi4', 'hi', 'hi@gmail.com', '4321234567'),
(60, 'Pratap Gourav Kendra Ticket', '2023-09-23', 'Foreign', 1, 5, 5, 5, 2, 3, '4000', 'Yes', 'order_Mety4vyM7Ie5rQ', 'Successful', 'pay_MetyTQ7JgVPMPy', 'hi', 'hello@gmail.com', '3212345676'),
(61, 'Water laser show', '2023-09-29', 'Foreign', 0, 0, 0, 2, 3, 4, '550', 'Yes', 'order_MevtjFasrRHZ2I', 'Successful', 'pay_MevtvjLs1sCLJ9', 'hello', 'hello@gmail.com', '3212345435');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking_details`
--
ALTER TABLE `booking_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_details`
--
ALTER TABLE `booking_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

    echo "Your payment was successful";

    $host = 'localhost';
    $username = 'root';
    $password = '';
    $database = 'razorpay';
    
    $conn = mysqli_connect($host, $username, $password, $database);
    
    // Check the connection
    if (!$conn) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "SELECT * FROM booking_details";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>OPTIONS</th><th>DATE</th><th>Indian_foreign</th><th>Infant_ticket</th><th>Kids_ticket</th><th>above12_ticket</th><th>water_infant_ticket</th><th>water_kids_ticket</th><th>water_above12_ticket</th><th>total_price</th><th>waterticket</th><th>order_id</th><th>payment_status</th><th>payment_id</th><th>name</th><th>email</th><th>number</th></tr>";
    
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["id"] . "</td><td>" . $row["options"] . "</td><td>" . $row["date"] . "</td><td>" . $row["Indian_foreign"] . "</td><td>" . $row["Infant_ticket"] . "</td><td>" . $row["kids_ticket"] . "</td><td>" . $row["above12_ticket"] . "</td><td>" . $row["water_infant_ticket"] . "</td><td>" . $row["water_kids_ticket"] . "</td><td>" . $row["water_above12_ticket"] . "</td><td>" . $row["total_price"] . "</td><td>" . $row["waterticket"] . "</td><td>" . $row["order_id"] . "</td><td>" . $row["payment_status"] . "</td><td>" . $row["payment_id"] . "</td><td>" . $row["name"] . "</td><td>" . $row["email"] . "</td><td>" . $row["number"] . "</td></tr>";
        }
    
        echo "</table>";
    } else {
        echo "No records found";
    }
mysqli_close($conn);

?>
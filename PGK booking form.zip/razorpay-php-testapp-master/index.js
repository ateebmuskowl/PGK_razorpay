const currentDate = new Date();
const datePicker = document.getElementById("date");
datePicker.min = currentDate.toISOString().split("T")[0];

const india= document.getElementById("btnradio1")
const foreign= document.getElementById("btnradio2")

const P_G_K= document.getElementById("P_ticket")
const water= document.getElementById("water_show")
const ticket_div = document.getElementById("tick")
const water_ticket_N = document.getElementById("water_ticket_N")
const water_ticket_Y = document.getElementById("water_ticket_Y")
const waterticketshow = document.getElementById("waterticketshow")

const time = document.getElementById("Time")
const spanC= document.getElementById("child")
const spanY= document.getElementById("youth")
const spanA= document.getElementById("adult")

const water_C_Price = document.getElementById("water_C_Price")
const water_Y_Price = document.getElementById("water_Y_Price")
const water_A_Price = document.getElementById("water_A_Price")


const C_Price = document.getElementById("C_Price")
const Y_Price = document.getElementById("Y_Price")
const A_Price = document.getElementById("A_Price")
const total = document.getElementById("Total_price")
// const inputprice = document.getElementById("input_price")


document.getElementById("btnradio1").checked = true

window.addEventListener("change", calculateSum)


function calculateSum() {

    const value1 = parseInt(C_Price.value);
    const value2 = parseInt(Y_Price.value);
    const value3 = parseInt(A_Price.value);
    let sum =0

    if(document.getElementById("btnradio2").checked == true){
        const val1 = value1*0;
        const val2 = value2*260;
        const val3 = value3*460;
         sum = val1 + val2 + val3 ;

        total.textContent = sum;

    }
    if(document.getElementById("btnradio1").checked == true){
    const val1 = value1*0;
    const val2 = value2*110;
    const val3 = value3*160;
     sum = val1 + val2 + val3 ;

    total.textContent = sum;
    }
    if(document.getElementById("water_ticket_N").checked == true){
        waterticketshow.style.display = "none";
    }
    if(document.getElementById("water_ticket_Y").checked == true){
        waterticketshow.style.display = "block";

    }
    if(document.getElementById("water_show").checked == true ){

        ticket_div.style.display = "none";
        waterticketshow.style.display = "none";

        const val1 = value1*0;
        const val2 = value2*50;
        const val3 = value3*100;
         sum = val1 + val2 + val3 ;
    
        total.textContent = sum;

        water_C_Price.value = "0";
        water_Y_Price.value = "0";
        water_A_Price.value = "0";
    }
    if(document.getElementById("P_ticket").checked == true){
        ticket_div.style.display = "block";

    }
    if(document.getElementById("P_ticket").checked == true && document.getElementById("water_ticket_Y").checked == true ){
        // const water_C_Price = document.getElementById("water_C_Price")
        // const water_Y_Price = document.getElementById("water_Y_Price")
        // const water_A_Price = document.getElementById("water_A_Price")
        const value4 = parseInt(water_C_Price.value)
        const value5 = parseInt(water_Y_Price.value)
        const value6 = parseInt(water_A_Price.value)

        const val4 = value4*0;
        const val5 = value5*50;
        const val6 = value6*100;
        const watershow = val4 + val5 + val6;
        sum = sum + watershow;
        total.textContent = sum;
    }
}
foreign.addEventListener("click", F_function)
india.addEventListener("click", I_function)
water.addEventListener("click",W_function)
P_G_K.addEventListener("click",P_G_K_function)

function F_function(){
    spanC.textContent = "₹ 0.00"
    spanY.textContent = "₹ 260.00"
    spanA.textContent = "₹ 460.00"
}

function I_function(){
    spanC.textContent = "₹ 0.00"
    spanY.textContent = "₹ 110.00"
    spanA.textContent = "₹ 160.00"
}

function P_G_K_function(){

    I_function();
    document.getElementById("btnradio1").checked = true
    foreign.addEventListener("click", F_function)
    india.addEventListener("click", I_function)
    time.textContent = "From: 9 am - 6 pm"

}

function W_function(){
    spanC.textContent = "₹ 0.00"
    spanY.textContent = "₹ 50.00"
    spanA.textContent = "₹ 100.00"
    time.textContent = "Start From 7pm"

    foreign.removeEventListener("click", F_function)
    india.removeEventListener("click", I_function)
}


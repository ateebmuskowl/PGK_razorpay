<?php

require('config.php');

session_start();

require('razorpay-php/Razorpay.php');
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$success = true;

$error = "Payment Failed";

if (empty($_POST['razorpay_payment_id']) === false)
{
    $api = new Api($keyId, $keySecret);

    try
    {
        // Please note that the razorpay order ID must
        // come from a trusted source (session here, but
        // could be database or something else)
        $attributes = array(
            'razorpay_order_id' => $_SESSION['razorpay_order_id'],
            'razorpay_payment_id' => $_POST['razorpay_payment_id'],
            'razorpay_signature' => $_POST['razorpay_signature'],
        );

       $resultt =  $api->utility->verifyPaymentSignature($attributes);

    //    echo "<pre>";print_r($resultt);exit;
    }
    catch(SignatureVerificationError $e)
    {
        $success = false;
        $error = 'Razorpay Error : ' . $e->getMessage();
    }
}

if ($success === true)
{
    $host = 'localhost';
$username = 'root';
$password = '';
$database = 'razorpay';

$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . $conn->connect_error);
}

$order_id= $_SESSION['razorpay_order_id'];
$payment_id= $_POST['razorpay_payment_id'];

$update = "UPDATE booking_details SET payment_id='$payment_id', payment_status='Successful' WHERE order_id = '$order_id'";
mysqli_query($conn, $update);
mysqli_close($conn);



$host = 'localhost';
$username = 'root';
$password = '';
$database = 'razorpay';

$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM booking_details WHERE order_id = '$order_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

   $id = $row["id"];
   $options = $row["options"];
   $date = $row["date"];
   $Indian_foreign = $row["Indian_foreign"];
   $Infant_ticket = $row["Infant_ticket"];
   $kids_ticket = $row["kids_ticket"];
   $above12_ticket = $row["above12_ticket"];
   $water_infant_ticket = $row["water_infant_ticket"];
   $water_kids_ticket = $row["water_kids_ticket"];
   $water_above12_ticket = $row["water_above12_ticket"];
   $total_price = $row["total_price"];
   $waterticket = $row["waterticket"];
   $order_id = $row["order_id"];
   $payment_status = $row["payment_status"];
   $payment_id = $row["payment_id"];
   $name = $row["name"];
   $email = $row["email"];
   $number = $row["number"];
    }
    mysqli_query($conn, $sql);
    mysqli_close($conn);

    if($options == "Pratap Gourav Kendra Ticket"){
        if($Indian_foreign == "Indian"){
            $infant =$Infant_ticket * 0;
            $kids =$kids_ticket * 110;
            $above12 =$above12_ticket * 160;
            $priceK = "₹110.00";
            $priceA = "₹160.00";
        }else{
            $infant =$Infant_ticket * 0;
            $kids =$kids_ticket * 260;
            $above12 =$above12_ticket * 460;
            $priceK = "₹260.00";
            $priceA = "₹460.00";
        }    
        $water_infant =$water_infant_ticket * 0;
        $water_kids =$water_kids_ticket * 50;
        $water_above12 =$water_above12_ticket * 100;
    }else{
        $water_infant =$water_infant_ticket * 0;
        $water_kids =$water_kids_ticket * 50;
        $water_above12 =$water_above12_ticket * 100;
        $infant = 0;
        $kids     = 0;
        $above12 = 0;
        if($Indian_foreign == "Indian"){
            $priceK = "₹110.00";
            $priceA = "₹160.00";
        }else{
            $priceK = "₹260.00";
            $priceA = "₹460.00";
        }
    }

    $htmlstyle= "<!DOCTYPE html>
        <body>
    
            <h1>Invoice Recipt</h1><br>
            <div class='invoice-box'>
                <table>
                    <tr class='top'>
                        <td colspan='2'>
                            <table>
                                <tr>
                                    <td class='title'>
                                        <img src='https://pgk.muskecards.com/wp-content/uploads/2023/06/pgk-logo-website-new.png' alt='Company logo' style='width: 100%; max-width: 100px' />
                                    </td>
                                
                                    <td>
                                        Order ID : $order_id<br />
                                        Booking Date: $date<br />
                                    </td>

                                    <td>
                                    <img id='printButton' src='./printing_446991.png' alt='PRINT' style='width: 50%; max-width: 30px' />
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
    
                    <tr class='information'>
                        <td colspan='2'>
                            <table>
                                <tr>
                                    <td>
                                        <b>Maharana Pratap Gorurav Kendra<br />
                                        Veer Shiromani Maharana Pratap Samiti<br />
                                        Tiger Hills, Manoharpura, Near</b>
                                    </td>
    
                                    <td>
                                        <b>$name<br />
                                        $email<br />
                                        $number</b>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    </table>
                    <table>
                    <tr class='heading green '>
                        <td>Payment Status:</td>
                        <td>    </td>
                        <td>    </td>
                        <td>$payment_status</td>
                    </tr>
    
                    <tr class='heading'>
                        <td>Tickets</td>
                        <td>Prices</td>
                        <td>Qty.</td>
                        <td>Total</td>
                    </tr>
    
                    <tr class='item'>
                        <td>P.G.K. Infant</td>
                        <td>₹0.00</td>
                        <td>$Infant_ticket</td>
                        <td>₹$infant.00</td>
                    </tr>
    
                    <tr class='item'>
                        <td>P.G.K. Kids</td>
                        <td>$priceK</td>
                        <td>$kids_ticket</td>
                        <td>₹$kids.00</td>
                    </tr>
    
                    <tr class='item'>
                        <td>P.G.K. Above 12</td>
                        <td>$priceA</td>
                        <td>$above12_ticket</td>
                        <td>₹$above12.00</td>
                    </tr>
    
                    <tr class='item'>
                        <td>Water Laser Infant</td>
                        <td>₹0.00</td>
                        <td>$water_infant_ticket</td>
                        <td>₹$water_infant.00</td>
                    </tr>
    
                    <tr class='item'>
                        <td>Water Laser Kids</td>
                        <td>₹50.00</td>
                        <td>$water_kids_ticket</td>
                        <td>₹$water_kids.00</td>
                    </tr>
    
                    <tr class='item'>
                        <td>Water Laser Above 12</td>
                        <td>₹100.00</td>
                        <td>$water_above12_ticket</td>
                        <td>₹$water_above12.00</td>
                    </tr>
    
                    <tr class='total'>
                        <td><b>Payment Id: $payment_id</b></td>
                        <td>    </td>
                        <td>Grand Total:</td>
                        <td>₹$total_price.00</td>
                    </tr>
                </table>
            </div>
        </body>
    </html>";



    } else {
                 echo "No records found";
             }
}
else
{
    $html = "<p>Your payment failed</p>
             <p>{$error}</p>";
}

// echo $htmlstyle;
$css = "<style>
body {
    font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    text-align: center;
    color: #777;
}

body h1 {
    font-weight: 300;
    margin-bottom: 0px;
    padding-bottom: 0px;
    color: #000;
}

body h3 {
    font-weight: 300;
    margin-top: 10px;
    margin-bottom: 20px;
    font-style: italic;
    color: #555;
}

body a {
    color: #06f;
}

.green{
    color: green;
}

.invoice-box {
    max-width: 800px;
    margin: auto;
    padding: 30px;
    border: 1px solid #eee;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
    font-size: 16px;
    line-height: 24px;
    font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    color: #555;
}

.invoice-box table {
    width: 100%;
    line-height: inherit;
    text-align: left;
    border-collapse: collapse;
}

.invoice-box table td {
    padding: 5px;
    vertical-align: top;
}

.invoice-box table tr td:nth-child(2) {
    text-align: right;
}
.invoice-box table tr td:nth-child(3) {
    text-align: right;
}
.invoice-box table tr td:nth-child(4) {
    text-align: right;
}

.invoice-box table tr.top table td {
    padding-bottom: 20px;
}

.invoice-box table tr.top table td.title {
    font-size: 45px;
    line-height: 45px;
    color: #333;
}

.invoice-box table tr.information table td {
    padding-bottom: 40px;
}

.invoice-box table tr.heading td {
    background: #eee;
    border-bottom: 1px solid #ddd;
    font-weight: bold;
}

.invoice-box table tr.details td {
    padding-bottom: 20px;
}

.invoice-box table tr.item td {
    border-bottom: 1px solid #eee;
}

.invoice-box table tr.item.last td {
    border-bottom: none;
}

.invoice-box table tr.total td:nth-child(2) {
    border-top: 2px solid #eee;
    font-weight: bold;
}

@media (max-width: 600px) { 
    .invoice-box {
        max-width: 600px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    .invoice-box table tr.top table td {
        width: 100%;
        display: block;
        text-align: center;
    }

    .invoice-box table tr.information table td {
        width: 100%;
        display: block;
        text-align: center;
    }
}
</style>"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice Recipt</title>
    <?php echo $css; // Output the CSS containing the media query ?>
</head>
<body>
    <?php echo $htmlstyle; // Output the HTML content ?>
    <script>
        document.getElementById('printButton').addEventListener('click', function () {
        window.print();
        });
    </script>
</body>
</html>
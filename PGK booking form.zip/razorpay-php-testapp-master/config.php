<?php

$keyId = 'rzp_test_j1cy2xvnObhnge';
$keySecret = 'qpOFvEvgC345C3QC9OPQl6T7';
$displayCurrency = 'INR';


error_reporting(E_ALL);
ini_set('display_errors', 1);
//6378884529